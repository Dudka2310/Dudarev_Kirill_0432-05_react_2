import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Menu, Layout } from 'antd'
import { useSelector } from 'react-redux'


const {Content } = Layout;

export const Navbar = (props) => {

  const { userId } = useSelector((state) => state.userLogs)
  
  const navItems = [
    {
      label: <Link to="/" >Главная</Link>,
      key: 'home',
    },
    {
      label: <Link to="/posts" >Посты</Link>,
      key: 'posts',
    },
  ];
  
  const regItem = [
    {
      label: <Link to="/login" >Вход</Link>,
      key: 'login',
    },
    {
      label: <Link to="/register" >Регистрация</Link>,
      key: 'register',
    },
  ];
  
  let newNavItems = null;
  
  if (userId.length === 0) {
    newNavItems = navItems.concat(regItem);
  } else {
    newNavItems = navItems;
  }

  //индикация страницы при переходе
  const [current, setCurrent] = useState('home');
  const onClick = (e) => {
    setCurrent(e.key);
  };

  return (
    <>
      <div>
        <nav>

          <Menu onClick={(e) => onClick(e)} selectedKeys={[current]} mode="horizontal" items={newNavItems} />
        </nav>
      </div>
      <div>
        <Content style={{ padding: '50px 50px' }}>
          <div className="site-layout-content" style={{ padding: 10, height: '100vh'}}>
            {props.children}
          </div>
        </Content>

      </div>
    </>
  )
}
