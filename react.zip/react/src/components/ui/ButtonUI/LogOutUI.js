import { FloatButton } from 'antd'
import { ExportOutlined } from '@ant-design/icons';

export const LogOutUI = ({ userId, onClick }) => {
    return(
        <>
         {userId && (() => {
                return (
                  <FloatButton
                    icon={<ExportOutlined />}
                    description="выход"
                    shape="square"
                    style={{
                      right: 164,
                  }}
                  onClick={onClick}
                />
                )
            })()}
        </>
    )
}