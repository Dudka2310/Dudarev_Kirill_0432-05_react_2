import './App.css';
import React, { useEffect, useState } from 'react';
import { Card } from 'antd'
import { HelloWorld, Navbar, Posts, PostPage } from './components/';
import { Routes, Route, useLocation } from 'react-router-dom'
import { LogIn } from './components/LoggingPages/LogIn';
import { SignUp } from './components/LoggingPages/SignUp';
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { LogOutUI } from './components/ui/ButtonUI/LogOutUI';


function App() {
    return (
      //служит для переходов по страницам
      <Navbar>
        <Routes> 
          <Route path='/' element={<Home />} />
          <Route path='/posts' element={<Posts />} />
          <Route path='/post/:id' element={<PostPage />} />
          <Route path='/hello/:id/temp/:dataid' element={<HelloWorld />} />
          <Route path='/login' element={<LogIn />} />
          <Route path='/register' element={<SignUp />} />
          <Route path='/user/:userid' element={ <NotFoud />} />
          <Route path='*' element={<NotFoud />} />
        </Routes>
        <div></div>

      </Navbar>
    )
  }

const Home = () => {
  const [users, setUsers] = useState([])

  const {userId, userName} = useSelector((state => state.userLogs))
  const dispatch = useDispatch()
  const navigation = useNavigate();

  const location = useLocation()
  console.log('location:', location)


  const getData = () => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(res => res.json())
      .then(res => {
        if (res && Array.isArray(res) && res.length > 0) {
          setUsers(res)
        } //typeof res == 'array'
      })

  }

  const loadUsers = () => {
    getData()
  }

  useEffect(() => {
    getData()
    // dispatch(getPosts)
  }, [])

  const logOut = () => {
    dispatch({type:'log_onfetch'})
    navigation('/')
  }

  const styles = {
    border: '1px solid #F5F5F5', //добавить в app.css
    padding: 10,
    margin: 'auto',
    
    marginBottom: 5,
    backgroundColor: '#FFFFFF'
  }

  return (
    <div>
      {userId && (() => {
                return (
                  <div>
                    Привет, {userName}
                  </div>
                )
            })()}
      <h2>Users: <button type="" onClick={() => { loadUsers() }}>Load users</button></h2>
      <div style={{ margin: 50, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
  {users && users.length > 0 &&
    users.map(user => {
      return (
        <div key={Math.random()}>
          <Card title={user.name} style={{ width: 200 }}>
            <p>{user.email}</p>
          </Card>
        </div>
      )
    })
  }
</div>
      
     <LogOutUI userId={userId} onClick={() => logOut()}/>
      
    </div>
  )
}

const NotFoud = () => {
  return (
    <> <h1>Page not found!</h1></>
  )
}
export default App;