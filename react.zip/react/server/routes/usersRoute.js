import express from 'express'
import UserLogs from '../db/schemas/usersSchema.js'

const router = express.Router()

//регистрация пользователей
router.post('/newregister', async (req, res) =>{
  const response = {
    ok: false,
    errMsg: 'Ошибка при регистрации'
  }

  const { body } = req
  try{

    const user = new UserLogs({
      name: body.name,
      fullname: body.fullname,
      email: body.email,
      login: body.login,
      password: body.password
    })

    await user.save()

    response.ok = true
    response.errMsg = ''
    response.userId = user._id.toString() //айди созданного пользователя в бд 
    response.name = user.name

    return res.status(200).json(response).send()
  } catch(error){
    return res.status(400).json(response).send()
  }
  }
)

//вход пользователя 
router.post('/login/new', async (req, res) =>{
  const response = {
    ok: false,
    errMsg: 'Ошибка входа'
  }
  response.ok = true
  response.errMsg = ''

  const {body} = req
   
  try{
    
    const user = await UserLogs.findOne({'login': body.login})
    
    //при совпадение паролей из запроса с бд
    if (user != null && body.password == user.password) { 
      response.userId = user._id
      response.name = user.name

      return res.status(200).json(response).send()  
    }
    //при несовпадение паролей из запроса с бд
    else if (user != null && body.password != user.password){
      response.answer = "Неверное имя или пароль пользователя"
      return res.status(200).json(response).send()
    }
    //пользователь отсутсвует 
    else{
      response.answer = "Пользователь не зарегистрирован"
      return res.status(200).json(response).send()
    }
    
  }catch(error){
    return res.status(400).json(response).send()
  }
  }
)

export default router