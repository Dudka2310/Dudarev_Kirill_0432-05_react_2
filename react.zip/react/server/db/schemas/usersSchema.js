import mongoose from 'mongoose'

const UserLogs = new mongoose.Schema({
  name: {type: String},
  fullname: {type: String},
  email: {type: String},
  login: {type: String},
  password: {type: String},
})

const model = mongoose.model('UserLogs', UserLogs)

export default model;